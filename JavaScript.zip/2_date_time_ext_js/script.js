var todays_date = new Date();
document.getElementById("dateTime").innerHTML = todays_date;